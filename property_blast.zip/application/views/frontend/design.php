<div class="container">
<div class="row">
<div class="row">
<div class="col-md-8 col-xs-12">
    <div class="row" style="border: 1px solid black; height: 550px; width: 100%;margin-left: 0%; background-image: url('bg1.jpg');  background-size:cover; opacity:0.5;">
    </div>
    <div class="row" style="margin-top: 2%;">
        <div class="col-md-6 col-xs-12">
            <div class="col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
                <div class="wan-spinner wan-spinner-1"  >
                    <a href="javascript:void(0)" class="minus" style="line-height: 0em;padding: 14px;">
                        -
                    </a>
                    <input type="text" value="1" style="width: 100px; padding: 14px;"/>
                    <a href="javascript:void(0)" class="plus" style="line-height: 0em;padding: 15px; width:0%;">
                        +
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xs-12" align="right" style = "padding: 0px;margin: 0px;">
            <div class="btn-group" role="group" aria-label="..." style="    width: 71%;">
                <div class="col-md-8 col-xs-12">
                    <div class="col-md-12 col-xs-12"  style="padding: 0px;margin: 0px;">
                        <button type="button" class="btn btn-warning" style="">
                            Undo
                        </button>
                        <button type="button" class="btn btn-warning" style="">
                            Redo
                        </button>
                    </div>
                </div>
                <div class="col-md-4 col-xs-12">
                    <div class="col-md-12 col-xs-12"  style="padding: 0px;margin: 0px;">
                        <button type="button" class="btn btn-primary" style="">
                            Save
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-md-4 col-xs-12">

<label for="exampleInputEmail1">
    TEXT
</label>
<div class="input-group "style="width: 100%; margin-top:5%;">
    <center>
        <textarea id="address" type="textbox" placeholder="" class="form-control"style="height: 100px;">
        </textarea>
    </center>
</div>
<div class="row mtop" >
    <div class="col-md-2 col-xs-12">
        <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
            <label class="textalign"for="exampleInputEmail1">
                SIZE:
            </label>
        </div>
    </div>
    <div class="col-md-10 col-xs-12">
        <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
            <select class="form-control" id="text-transform" style="width: 100%; font-size: 11px; padding: 0px;">
                <option value="none">
                    <small>
                        font  size
                    </small>
                </option>
                <option value="capitalize">
                    <small>
                        capitalize
                    </small>
                </option>
                <option value="uppercase">
                    <small>
                        uppercase
                    </small>
                </option>
                <option value="lowercase">
                    <small>
                        lowercase
                    </small>
                </option>
                <option value="initial">
                    <small>
                        initial
                    </small>
                </option>
                <option value="inherit">
                    <small>
                        inherit
                    </small>
                </option>
            </select>
        </div>
    </div>
</div>
<div class="row mtop" >
    <div class="col-md-2 col-xs-12">
        <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
            <label class="textalign"for="exampleInputEmail1">
                FONT:
            </label>
        </div>
    </div>
    <div class="col-md-10 col-xs-12">
        <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
            <select class="form-control" id="text-transform" style="width: 100%; font-size: 11px; padding: 0px;">
                <option value="none">
                    <small>
                        font  size
                    </small>
                </option>
                <option value="capitalize">
                    <small>
                        capitalize
                    </small>
                </option>
                <option value="uppercase">
                    <small>
                        uppercase
                    </small>
                </option>
                <option value="lowercase">
                    <small>
                        lowercase
                    </small>
                </option>
                <option value="initial">
                    <small>
                        initial
                    </small>
                </option>
                <option value="inherit">
                    <small>
                        inherit
                    </small>
                </option>
            </select>
        </div>
    </div>
</div>
<div class="row mtop" >
    <div class="col-md-2 col-xs-12">
        <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
            <label class="textalign"for="exampleInputEmail1">
                COLOR:
            </label>
        </div>
    </div>
    <div class="col-md-10 col-xs-12">
        <div class="rect">
            <div class="col-md-4 col-xs-12" style="padding: 0px;margin: 0px;">
                <div class="col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
                    <div class="square">
                    </div>
                </div>
            </div>
            <div class="col-md-8 col-xs-12">
                <div class=" col-md-12 col-xs-12">
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row mtop" >
    <div class="col-md-2 col-xs-12">
        <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
            <label class="textalign"for="exampleInputEmail1">
                ALIGN:
            </label>
        </div>
    </div>
    <div class="col-md-10 col-xs-12">
        <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
            <div class="btn-group" role="group" aria-label="..." style="width : 100%;">
                <button type="button" class="btn btn-default" style="width: 25%;" ><span class="glyphicon glyphicon-align-left" aria-hidden="true"></button>
                <button type="button" class="btn btn-default" style="width: 25%;"><span class="glyphicon glyphicon-align-right" aria-hidden="true"></button>
                <button type="button" class="btn btn-default" style="width: 25%;"><span class="glyphicon glyphicon-align-center" aria-hidden="true"></button>
                <button type="button" class="btn btn-default" style="width: 25%;"><span class="glyphicon glyphicon-align-justify" aria-hidden="true"></button>
            </div>
        </div>
    </div>
</div>
<div class="row mtop" >
    <div class="col-md-2 col-xs-12">
        <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
            <label class="textalign"for="exampleInputEmail1">
                STYLE:
            </label>
        </div>
    </div>
    <div class="col-md-10 col-xs-12">
        <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
            <div class="btn-group" role="group" aria-label="..." style="width : 100%;">
                <button type="button" class="btn btn-default" style="width: 25%;" ><span class="glyphicon glyphicon-bold" aria-hidden="true"></button>
                <button type="button" class="btn btn-default" style="width: 25%;"><span class="glyphicon glyphicon-italic" aria-hidden="true"></button>
                <button type="button" class="btn btn-default" style="width: 25%;"><span class="glyphicon glyphicon-magnet" aria-hidden="true"></button>
                <button type="button" class="btn btn-default" style="width: 25%;"><span class="glyphicon glyphicon-list" aria-hidden="true"></button>
            </div>
        </div>
    </div>
</div>
<div class="row mtop" >
    <div class="col-md-2 col-xs-12">
        <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
            <label class="textalign1"for="exampleInputEmail1">
                IMAGE:
            </label>
        </div>
    </div>
    <div class="col-md-10 col-xs-12">
        <div class="rect1">
            <div class="col-md-4 col-xs-12" style="padding: 0px;margin: 0px;">
                <div class="col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
                    <button type="button" class="btn btn-default btn-sm" style="background-color:lightgray;">Choose File</button>
                </div>
            </div>
            <div class="col-md-8 col-xs-12">
                <div class=" col-md-12 col-xs-12">
                    <label class="textalign"for="exampleInputEmail1">
                        <small>No file choosen</small>
                    </label>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row" >
    <div class="col-md-12 col-xs-12">
        <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
            <label class="textalign1"for="exampleInputEmail1">
                COLOR STYLES:
            </label>
        </div>
    </div>
</div>
<div class="row mtop1 " >
    <div class="col-md-9 col-xs-12"style="margin:0px;padding:0px;" >
        <div class="col-md-12"style="magin-bottom:10px">
            <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-xs-12"style="margin:0px;padding:0px;">
        <div class="col-md-12 col-xs-12">
            <label class="textalign"for="exampleInputEmail1">
                SAMLPLE1
            </label>
        </div>
    </div>
</div>
<div class="row mtop1">
    <div class="col-md-9 col-xs-12"style="margin:0px;padding:0px;">
        <div class="col-md-12 col-xs-12"style="magin-bottom:10px">
            <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-xs-12"style="margin:0px;padding:0px;">
        <div class="col-md-12">
            <label class="textalign"for="exampleInputEmail1">
                SAMLPLE2
            </label>
        </div>
    </div>
</div>
<div class="row mtop1">
    <div class="col-md-9"style="margin:0px;padding:0px;">
        <div class="col-md-12 col-xs-12"style="magin-bottom:10px">
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-xs-12"style="margin:0px;padding:0px;">
        <div class="col-md-12 col-xs-12">
            <label class="textalign"for="exampleInputEmail1">
                SAMLPLE3
            </label>
        </div>
    </div>
</div>
<div class="row mtop1">
    <div class="col-md-9 col-xs-12" style="margin:0px;padding:0px;">
        <div class="col-md-12 col-xs-12"style="magin-bottom:10px">
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-xs-12" style="margin:0px;padding:0px;">
        <div class="col-md-12 col-xs-12">
            <label class="textalign"for="exampleInputEmail1">
                SAMLPLE4
            </label>
        </div>
    </div>
</div>
<div class="row mtop1">
    <div class="col-md-9 col-xs-12" style="margin:0px;padding:0px;">
        <div class="col-md-12 col-xs-12"style="magin-bottom:10px">
            <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div class="square1"></div>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-xs-12" style="margin:0px;padding:0px;">
        <div class="col-md-12">
            <label class="textalign"for="exampleInputEmail1">
                SAMLPLE5
            </label>
        </div>
    </div>
</div>
</div>
</div>
</div>
<div class="row mtop">
    <div class="col-md-6 col-xs-12" style="margin:0px;padding :0px;">
        <button type="button" class="btn btn-primary">GO BACK</button>
    </div>
    <div class="col-md-6 col-xs-12"align="right" style="margin:0px;padding:0px;">
        <button type="button" class="btn btn-primary">SAVE&CONTINUE</button>
    </div>
</div>
</div>