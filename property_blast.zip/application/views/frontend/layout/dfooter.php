    <script src="<?php echo base_url() ?>public/frontend/js/jquery-1.12.0.js"></script>
    <script src="<?php echo base_url() ?>public/frontend/js/bootstrap.js"></script>
    <script src="<?php echo base_url() ?>public/frontend/js/parallax.js"></script>
    <script> var base_url = '<?php echo base_url(); ?>' ;</script>
    </body>
</html>
