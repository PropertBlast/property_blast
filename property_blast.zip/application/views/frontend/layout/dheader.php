
<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <title>Major Properties - Real Estate</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <!-- google fonts -->
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

        <!-- header css & js resources -->
        <link rel="stylesheet" href="<?php echo base_url() ?>public/frontend//css/font-awesome.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>public/frontend/css/master.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>public/frontend/css/style.css">
        <link rel="stylesheet" href="<?php echo base_url() ?>public/frontend/css/bootstrap.css">
        <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>-->
    </head>
    <body>
