<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Admin Dashboard</h2>   
                        <h5>Welcome <?php if ($this->session->userdata('admin_data') != "") { echo $this->session->userdata['admin_data']['username'];} ?> , Love to see you back. </h5>
                    </div>
                </div>              
                        
    </div>
             <!-- /. PAGE INNER  -->
            </div>