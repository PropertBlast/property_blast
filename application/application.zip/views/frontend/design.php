<body class="page page-id-13800 page-template page-template-flyer-design page-template-template-create-flyer page-template-flyer-designtemplate-create-flyer-php fusion-body no-tablet-sticky-header no-mobile-sticky-header no-mobile-slidingbar no-mobile-totop mobile-logo-pos-left layout-boxed-mode mobile-menu-design-modern do-animate" data-spy="scroll">
      <div id="wrapper" class="">
         <div class="topbar-wrapper">
         </div>
         <div class="fusion-main-menu-none" style="margin-bottom:10px;">
            <div class="fusion-header-wrapper fhd" style="">
               <ul id="top-nav-menu" class="fusion-top-nav-menu">
                  <li>
                     <a href="http://45.33.34.56/propblast/subscribe/">Subscribe</a>
                  </li>
                  <li>
                     <a href="http://45.33.34.56/propblast/?page_id=8">Register</a>
                  </li>
                  <li>
                     <a href="http://45.33.34.56/propblast/?page_id=13705">Login</a>
                  </li>
               </ul>
            </div>
            <br><br><br>
         </div>
         <div id="home" style="position:relative;top:1px;"></div>
         <div class="fusion-header-wrapper" style="">
            <div class="fusion-header-v1 fusion-logo-left fusion-sticky-menu-1 fusion-sticky-logo-1 fusion-mobile-logo- fusion-mobile-menu-design-modern">
               <div class="fusion-header-sticky-height" style="height: 111px;"></div>
               <div class="fusion-header" style="height: 111px;">
                  <div class="fusion-row">
                     <div class="fusion-logo" data-margin-top="31px" data-margin-bottom="31px" data-margin-left="0px" data-margin-right="0px" style="">
                        <a href="http://45.33.34.56/propblast">
                           <img src="./Propert Blast - Create New Flyer_files/your_logo_here.png" width="205" height="60" alt="Propert Blast" class="fusion-logo-1x fusion-standard-logo">
                           <img src="./Propert Blast - Create New Flyer_files/travel-logo2x1.png" width="205" height="60" alt="Propert Blast" style="width:205px; max-height: 60px; height: auto;" class="fusion-standard-logo fusion-logo-2x">
                           <!-- mobile logo -->
                           <!-- sticky header logo -->
                           <img src="./Propert Blast - Create New Flyer_files/agency_logo1x.png" alt="Propert Blast" class="fusion-logo-1x fusion-sticky-logo-1x">
                           <img src="./Propert Blast - Create New Flyer_files/agency_logo1x.png" alt="Propert Blast" class="fusion-logo-2x fusion-sticky-logo-2x">
                        </a>
                     </div>
                     <div class="fusion-main-menu">
                        <ul id="menu-main-menu" class="fusion-menu">
                           <li id="menu-item-13406" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13406"><a href="http://45.33.34.56/propblast/home/">Home</a></li>
                           <li id="menu-item-13681" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13681"><a href="http://45.33.34.56/propblast/custom-flyer-design/">Products</a></li>
                           <li id="menu-item-13682" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13682"><a href="http://45.33.34.56/propblast/custom-pricing-page/">Pricing</a></li>
                           <li id="menu-item-13684" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13684"><a href="http://45.33.34.56/propblast/travel-blog/">Blog</a></li>
                           <li id="menu-item-13689" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13689"><a href="http://45.33.34.56/propblast/about-us-3/">About Us</a></li>
                           <li id="menu-item-13690" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13690"><a href="http://45.33.34.56/propblast/shop/">Order Now</a></li>
                           <li id="menu-item-13691" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13691"><a href="http://45.33.34.56/propblast/contact-us/">Contact  Us</a></li>
                           <li class="fusion-custom-menu-item fusion-menu-cart fusion-main-menu-cart"><a class="fusion-main-menu-icon" href="http://45.33.34.56/propblast/cart/"></a></li>
                        </ul>
                     </div>
                     <div class="fusion-main-menu fusion-sticky-menu">
                        <ul id="menu-main-menu-1" class="fusion-menu">
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13406"><a href="http://45.33.34.56/propblast/home/">Home</a></li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13681"><a href="http://45.33.34.56/propblast/custom-flyer-design/">Products</a></li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13682"><a href="http://45.33.34.56/propblast/custom-pricing-page/">Pricing</a></li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13684"><a href="http://45.33.34.56/propblast/travel-blog/">Blog</a></li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13689"><a href="http://45.33.34.56/propblast/about-us-3/">About Us</a></li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13690"><a href="http://45.33.34.56/propblast/shop/">Order Now</a></li>
                           <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13691"><a href="http://45.33.34.56/propblast/contact-us/">Contact  Us</a></li>
                           <li class="fusion-custom-menu-item fusion-menu-cart fusion-main-menu-cart"><a class="fusion-main-menu-icon" href="http://45.33.34.56/propblast/cart/"></a></li>
                        </ul>
                     </div>
                     <div class="fusion-mobile-menu-icons"><a href="http://45.33.34.56/propblast/create-new-flyer/#" class="fusion-icon fusion-icon-bars"></a><a href="http://45.33.34.56/propblast/cart/" class="fusion-icon fusion-icon-shopping-cart"></a></div>
                     <div class="fusion-mobile-nav-holder">
                        <ul id="menu-main-menu" class="fusion-menu">
                           <li id="mobile-menu-item-13406" class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/home/">Home</a></li>
                           <li id="mobile-menu-item-13681" class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/custom-flyer-design/">Products</a></li>
                           <li id="mobile-menu-item-13682" class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/custom-pricing-page/">Pricing</a></li>
                           <li id="mobile-menu-item-13684" class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/travel-blog/">Blog</a></li>
                           <li id="mobile-menu-item-13689" class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/about-us-3/">About Us</a></li>
                           <li id="mobile-menu-item-13690" class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/shop/">Order Now</a></li>
                           <li id="mobile-menu-item-13691" class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/contact-us/">Contact  Us</a></li>
                        </ul>
                     </div>
                     <div class="fusion-mobile-nav-holder fusion-mobile-sticky-nav-holder">
                        <ul id="menu-main-menu-1" class="fusion-menu">
                           <li class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/home/">Home</a></li>
                           <li class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/custom-flyer-design/">Products</a></li>
                           <li class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/custom-pricing-page/">Pricing</a></li>
                           <li class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/travel-blog/">Blog</a></li>
                           <li class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/about-us-3/">About Us</a></li>
                           <li class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/shop/">Order Now</a></li>
                           <li class="fusion-mobile-nav-item" style=""><a href="http://45.33.34.56/propblast/contact-us/">Contact  Us</a></li>
                        </ul>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div class="fusion-page-title-bar fusion-page-title-bar-breadcrumbs fusion-page-title-bar-center">
         <div class="fusion-page-title-row">
            <div class="fusion-page-title-wrapper" style="opacity: 0.133333;">
               <div class="fusion-page-title-captions">
                  <h1 class="entry-title" data-fontsize="40" data-lineheight="NaN" style="font-size: 36.574px;">Create New Flyer</h1>
                  <div class="fusion-page-title-secondary">
                     <div class="fusion-breadcrumbs"><span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a itemprop="url" href="http://45.33.34.56/propblast"><span itemprop="title">Home</span></a></span><span class="fusion-breadcrumb-sep">/</span><span class="breadcrumb-leaf">Create New Flyer</span></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <div id="main" class="clearfix " style="">
         <div class="fusion-row" style="">
            <!-- order number -->
            <div class="order-number">
               <p>Order # : <span class="order">PRPBXC124</span></p>
            </div>
            <!-- flyer accordion -->
            <div class="accordian fusion-accordian">
               <div class="panel-group" id="accordion-4104-3">
                  <div class="fusion-panel panel-default">
                     <!-- flyer toggle heading -->
                     <div class="panel-heading">
                        <h4 class="panel-title toggle" data-fontsize="18" data-lineheight="22">
                           <a class="collapsed" data-toggle="collapse" data-parent="#accordion-4104-3" data-target="#toggle-id-1" href="#toggle-id-1">
                              <div class="flyer-heading"><span>Step 1 : </span>Start.</div>
                           </a>
                        </h4>
                     </div>
                     <!-- end: flyer toggle heading -->
                     <!-- flyer toggle content -->
                     <div id="toggle-id-1" class="panel-collapse collapse" style="height: 0px;">
                        <div class="panel-body toggle-content">
                           <!-- columns three fourth -->
                           <div class="fusion-three-fourth fusion-layout-column fusion-column-last centered-column">
                              <div class="create-new-flyer">
                                 <h2 class="section-sub-heading" data-fontsize="22" data-lineheight="30">Create new Flyer</h2>
                              </div>
                              <div class="use-flyer">
                                 <h2 class="section-sub-heading" data-fontsize="22" data-lineheight="30">Use previous Flyer</h2>
                                 <ul class="list-unstyled previous-flyers">
                                    <li><a href="http://45.33.34.56/propblast/create-new-flyer/#">123 Easy Street <span>(Delivered : 22-11-2015)</span></a>
                                    </li>
                                    <li><a href="http://45.33.34.56/propblast/create-new-flyer/#">123 Easy Street <span>(Delivered : 26-11-2015)</span></a></li>
                                    <li><a href="http://45.33.34.56/propblast/create-new-flyer/#">123 Easy Street <span>(Delivered : 27-11-2015)</span></a></li>
                                    <li><a href="http://45.33.34.56/propblast/create-new-flyer/#">123 Easy Street <span>(Delivered : 08-12-2015)</span></a></li>
                                    <li><a href="http://45.33.34.56/propblast/create-new-flyer/#">123 Easy Street <span>(Delivered : 10-12-2015)</span></a></li>
                                    <li><a href="http://45.33.34.56/propblast/create-new-flyer/#">More..</a></li>
                                 </ul>
                              </div>
                              <div class="create-own-flyer">
                                 <h2 class="section-sub-heading" data-fontsize="22" data-lineheight="30">Upload your own Flyer</h2>
                                 <p>Select your file to Upload</p>
                                 <div class="fileUpload button-upload">
                                    <span>Upload File</span>
                                    <input type="file" class="upload">
                                 </div>
                                 <div class="checkbox-wrap">
                                    <div class="checkbox-styled">
                                       <p><input type="checkbox" value="None" id="accept-terms" name="check" checked="">
                                          <label for="accept-terms"></label>
                                          Accept Terms &amp; Conditions
                                       </p>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam corrupti, amet. Quisquam itaque sunt similique inventore tenetur esse, saepe, necessitatibus voluptatem ab. Nostrum cupiditate deserunt quisquam quasi cum, sint vel.</p>
                                 </div>
                              </div>
                           </div>
                           <!-- column three fourth -->
                           <!-- flyer navigation -->
                           <div class="flyer-navigation clearfix">
                              <a class="fusion-button button-flat button-round button-large button-default" href="http://45.33.34.56/propblast/create-new-flyer/#">
                              <span class="fusion-button-text">Go Back</span>
                              </a>
                              <a class="right fusion-button button-flat button-round button-large button-default" href="http://45.33.34.56/propblast/create-new-flyer/#">
                              <span class="fusion-button-text">Save &amp; Continue</span>
                              </a>
                           </div>
                           <!-- end: flyer navigation -->
                        </div>
                     </div>
                     <!-- end: flyer toggle content -->
                  </div>
                  <div class="fusion-panel panel-default">
                     <div class="panel-heading">
                        <h4 class="panel-title toggle" data-fontsize="18" data-lineheight="22">
                           <a data-toggle="collapse" data-parent="#accordion-4104-3" data-target="#toggle-id-2" href="#toggle-id-2" class="collapsed">
                              <div class="flyer-heading"><span>Step 2 : </span>Choose Your Flyer.</div>
                           </a>
                        </h4>
                     </div>
                     <div id="toggle-id-2" class="panel-collapse collapse ">
                        <div class="panel-body toggle-content">
                           <p>Quisque malesuada placerat nisl. Pellentesque ut neque. Proin sapien ipsum, porta a, auctor quis, euismod ut, mi. Fusce vel dui. Nam at tortor in tellus interdum sagittis.
                              Curabitur a felis in nunc fringilla tristique. Praesent ac massa at ligula laoreet iaculis. Ut non enim eleifend felis pretium feugiat. Nam at tortor in tellus interdum sagittis. Lorem ipsum dolor sit amet, consectetuer adipiscing elit.
                              In ut quam vitae odio lacinia tincidunt. Nunc interdum lacus sit amet orci. Etiam sit amet orci eget eros faucibus tincidunt. Nullam tincidunt adipiscing enim. Suspendisse eu ligula.
                           </p>
                           <div class="choose-your-flyer">
                              <h2 class="section-sub-heading" data-fontsize="22" data-lineheight="30">Choose Your Flyer</h2>
                           </div>
                           <div class="filterable-flyer-wrap">
                              <nav class="primary clearfix">
                                 <ul class="flyer-filter-menu list-inline mb-30">
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter="*">Show All</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-1">Flyer 1</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-2">Flyer 2</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-3">Flyer 3</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-4">Flyer 4</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-5">Flyer 5</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-6">Flyer 6</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-7">Flyer 7</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-8">Flyer 8</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-9">Flyer 9</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-10">Flyer 10</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-11">Flyer 11</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-12">Flyer 12</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-13">Flyer 13</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-14">Flyer 14</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-15">Flyer 15</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-16">Flyer 16</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-17">Flyer 17</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-18">Flyer 18</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-19">Flyer 19</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-20">Flyer 20</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-21">Flyer 21</a></li>
                                    <li><a class="button-default button-flat button-small" href="http://45.33.34.56/propblast/create-new-flyer/#" data-filter=".flyer-22">Flyer 22</a></li>
                                 </ul>
                              </nav>
                              <section class="flyer-filter-wrap main container-fluid">
                                 <div class="row">
                                    <div class="filtered-items col-md-7">
                                       <div class="flyer-filter isotope row" style="position: relative; height: 0px;">
                                          <div class="col-md-4 flyer-1" data-my-order="1" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 1</span>
                                          </div>
                                          <div class="col-md-4 flyer-1" data-my-order="2" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 1</span>
                                          </div>
                                          <div class="col-md-4 flyer-1" data-my-order="3" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 1</span>
                                          </div>
                                          <div class="col-md-4 flyer-2" data-my-order="4" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 2</span>
                                          </div>
                                          <div class="col-md-4 flyer-2" data-my-order="5" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 2</span>
                                          </div>
                                          <div class="col-md-4 flyer-2" data-my-order="6" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 2</span>
                                          </div>
                                          <div class="col-md-4 flyer-3" data-my-order="7" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 3</span>
                                          </div>
                                          <div class="col-md-4 flyer-3" data-my-order="8" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 3</span>
                                          </div>
                                          <div class="col-md-4 flyer-4" data-my-order="9" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 4</span>
                                          </div>
                                          <div class="col-md-4 flyer-5" data-my-order="10" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 5</span>
                                          </div>
                                          <div class="col-md-4 flyer-5" data-my-order="11" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 5</span>
                                          </div>
                                          <div class="col-md-4 flyer-6" data-my-order="12" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 6</span>
                                          </div>
                                          <div class="col-md-4 flyer-6" data-my-order="13" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 6</span>
                                          </div>
                                          <div class="col-md-4 flyer-6" data-my-order="14" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 6</span>
                                          </div>
                                          <div class="col-md-4 flyer-7" data-my-order="15" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 7</span>
                                          </div>
                                          <div class="col-md-4 flyer-7" data-my-order="16" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 7</span>
                                          </div>
                                          <div class="col-md-4 flyer-8" data-my-order="17" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 8</span>
                                          </div>
                                          <div class="col-md-4 flyer-8" data-my-order="18" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 8</span>
                                          </div>
                                          <div class="col-md-4 flyer-8" data-my-order="19" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 8</span>
                                          </div>
                                          <div class="col-md-4 flyer-9" data-my-order="20" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 9</span>
                                          </div>
                                          <div class="col-md-4 flyer-9" data-my-order="21" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 9</span>
                                          </div>
                                          <div class="col-md-4 flyer-9" data-my-order="22" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 9</span>
                                          </div>
                                          <div class="col-md-4 flyer-9" data-my-order="23" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 0</span>
                                          </div>
                                          <div class="col-md-4 flyer-10" data-my-order="24" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 10</span>
                                          </div>
                                          <div class="col-md-4 flyer-10" data-my-order="25" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 10</span>
                                          </div>
                                          <div class="col-md-4 flyer-11" data-my-order="26" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 11</span>
                                          </div>
                                          <div class="col-md-4 flyer-12" data-my-order="27" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 12</span>
                                          </div>
                                          <div class="col-md-4 flyer-12" data-my-order="28" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 12</span>
                                          </div>
                                          <div class="col-md-4 flyer-13" data-my-order="29" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 13</span>
                                          </div>
                                          <div class="col-md-4 flyer-14" data-my-order="30" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 14</span>
                                          </div>
                                          <div class="col-md-4 flyer-15" data-my-order="31" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 15</span>
                                          </div>
                                          <div class="col-md-4 flyer-15" data-my-order="32" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 15</span>
                                          </div>
                                          <div class="col-md-4 flyer-16" data-my-order="33" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 16</span>
                                          </div>
                                          <div class="col-md-4 flyer-17" data-my-order="34" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 17</span>
                                          </div>
                                          <div class="col-md-4 flyer-17" data-my-order="35" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 17</span>
                                          </div>
                                          <div class="col-md-4 flyer-18" data-my-order="36" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 18</span>
                                          </div>
                                          <div class="col-md-4 flyer-18" data-my-order="37" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 18</span>
                                          </div>
                                          <div class="col-md-4 flyer-19" data-my-order="38" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 19</span>
                                          </div>
                                          <div class="col-md-4 flyer-20" data-my-order="39" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 20</span>
                                          </div>
                                          <div class="col-md-4 flyer-20" data-my-order="40" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 20</span>
                                          </div>
                                          <div class="col-md-4 flyer-21" data-my-order="41" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 21</span>
                                          </div>
                                          <div class="col-md-4 flyer-22" data-my-order="42" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 22</span>
                                          </div>
                                          <div class="col-md-4 flyer-22" data-my-order="43" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 22</span>
                                          </div>
                                          <div class="col-md-4 flyer-22" data-my-order="44" style="position: absolute; left: 0px;">
                                             <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg"><span>Flyer 22</span>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="selected-item col-md-5">
                                       <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg">
                                    </div>
                                 </div>
                              </section>
                           </div>
                           <!-- filterable flyer wrap -->
                           <!-- flyer navigation -->
                           <div class="flyer-navigation clearfix">
                              <a class="fusion-button button-flat button-round button-large button-default" href="http://45.33.34.56/propblast/create-new-flyer/#">
                              <span class="fusion-button-text">Go Back</span>
                              </a>
                              <a class="right fusion-button button-flat button-round button-large button-default" href="http://45.33.34.56/propblast/create-new-flyer/#">
                              <span class="fusion-button-text">Save &amp; Continue</span>
                              </a>
                           </div>
                           <!-- end: flyer navigation -->
                        </div>
                     </div>
                  </div>
                  <div class="fusion-panel panel-default">
                     <!-- flyer toggle heading -->
                     <div class="panel-heading">
                        <h4 class="panel-title toggle" data-fontsize="18" data-lineheight="22">
                           <a class="active" data-toggle="collapse" data-parent="#accordion-4104-3" data-target="#toggle-id-3" href="#toggle-id-3">
                              <div class="flyer-heading"><span>Step 3 : </span>Design your Flyer.</div>
                           </a>
                        </h4>
                     </div>
                     <!-- end: flyer toggle heading -->
                     <!-- flyer toggle content -->
                     <div id="toggle-id-3" class="panel-collapse collapse ">
                     <div class="panel-body toggle-content">
                     <div class="design-flyer-wrap container-fluid">


                     <div class="container">

<div class="row">
<div class="col-md-8 col-xs-12">
    <div class="row" align="center" style="overflow-x: scroll;overflow-y: scroll;border: 1px solid black; height: 766px; width: 620px;margin-left: 0%;  background-size:cover;">
        <canvas id="myCanvas" style="border:1px solid #000000;">
        </canvas>
    </div>
    <div class="row" style="margin-top: 2%;">
        <div class="col-md-4 col-xs-12" style = "margin-bottom: 5px;">
            <div class="wan-spinner wan-spinner-1 dropup ">
                <a href="javascript:void(0)" class="minus" style="line-height: 0em;padding: 14px;">
                    -
                </a>
                <input type="text" class="dropdown-toggle" id="zoom"value="100" style="width: 100px; padding: 14px;" readonly  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"/>
                <ul id="zoom-menu"class="dropdown-menu" aria-labelledby="zoom">
                    <li value="50"><a>50</a></li>
                    <li value="60"><a>60</a></li>
                    <li value="75"><a>75</a></li>
                    <li value="100"><a>100</a></li>
                    <li value="120"><a>120</a></li>
                    <li value="150"><a>150</a></li>
                    <li value="200"><a>200</a></li>
                </ul>
                <a href="javascript:void(0)" class="plus" style="line-height: 0em;padding: 15px; width:0%;">
                    +
                </a>
            </div>
        </div>
        <div class="col-md-8 col-xs-12" align="right" style = "padding: 0px;margin: 0px;margin-bottom: 5px;">
            <div class="btn-group" role="group" aria-label="..." >
                <div class="col-md-8 col-xs-12" align="center" style = "margin-bottom: 5px;">
                    <div class="btn-group">
                    <button type="button" id="undobtn" style="width: 50px" class="btn btn-default btn-sm">
                        Undo
                    </button>
                    <button type="button" id="redobtn" style="width: 50px" class="btn btn-default btn-sm">
                        Redo
                    </button>
                    </div>
                </div>
                <div class="col-md-4 col-xs-12" align="center">
                    <button type="button" style="width: 50px" class="btn btn-primary btn-sm">
                        Save
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-md-4 col-xs-12">
<div id="settingOpt" align="right" style="display: none;">
    <!--<button type="button" id="settingbtn" class="btn btn-primary btn-sm">Settings</button>-->
</div>
<div id="colorStyleOpt">
<div class="row" >
        <div style="font-size: 16px;margin: 0px;padding: 0px;font-weight: bold;margin-top: 15px;">
            COLOR STYLES:
        </div>
        <hr style="width: 100%;margin: 0px;padding: 0px; margin-bottom: 10px;">
</div>
<div class="row color-pallet-row colorRow" id="Ccol-1">
    <div class="col-md-9 col-xs-8" style="margin: 0px;padding: 0px;" >
        <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
            <div id = "C11" class="square1"></div>
        </div>
        <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
            <div id = "C12" class="square1"></div>
        </div>
        <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
            <div id = "C13" class="square1"></div>
        </div>
        <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
            <div id = "C14" class="square1"></div>
        </div>
        <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
            <div id = "C15" class="square1"></div>
        </div>
        <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
            <div id = "C16" class="square1"></div>
        </div>
    </div>
    <div class="col-md-3 col-xs-4" class="txt" style="margin:0px;padding:0px;">
            <label class="textalign1"for="exampleInputEmail1">
                SAMLPLE1
            </label>
    </div>
</div>
<div class="row color-pallet-row colorRow" id="Ccol-2">
    <div class="col-md-9 col-xs-8"style="margin:0px;padding:0px;">
            <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
                <div id = "C21" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C22" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C23" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C24" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C25" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C26" class="square1"></div>
            </div>
    </div>
    <div class="col-md-3 col-xs-4" class="txt" style="margin:0px;padding:0px;">
            <label class="textalign1"for="exampleInputEmail1">
                SAMLPLE2
            </label>
    </div>
</div>
<div class="row color-pallet-row colorRow" id="Ccol-3">
    <div class="col-md-9 col-xs-8"style="margin:0px;padding:0px;">
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C31" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C32" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C33" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C34" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C35" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C36" class="square1"></div>
            </div>
    </div>
    <div class="col-md-3 col-xs-4" class="txt" style="margin:0px;padding:0px;" >
            <label class="textalign1"for="exampleInputEmail1">
                SAMLPLE3
            </label>
    </div>
</div>
<div class="row color-pallet-row colorRow" id="Ccol-4">
    <div class="col-md-9 col-xs-8" style="margin:0px;padding:0px;">
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C41" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C42" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C43" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C44" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C45" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C46" class="square1"></div>
            </div>
    </div>
    <div class="col-md-3 col-xs-4" class="txt" style="margin:0px;padding:0px;">
            <label class="textalign1"for="exampleInputEmail1">
                SAMLPLE4
            </label>
    </div>
</div>
<div class="row color-pallet-row colorRow" id="Ccol-5" >
    <div class="col-md-9 col-xs-8" style="margin:0px;padding:0px;">
            <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
                <div id = "C51" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C52" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C53" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C54" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C55" class="square1"></div>
            </div>
            <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                <div id = "C56" class="square1"></div>
            </div>
    </div>
    <div class="col-md-3 col-xs-4" class="txt" style="margin:0px;padding:0px;">
            <label class="textalign1"for="exampleInputEmail1">
                SAMLPLE5
            </label>
    </div>
</div>
<div class="row color-pallet-row colorRow" id="Ccol-6">
        <div class="col-md-9 col-xs-8" style="margin:0px;padding:0px;">
                <div class="col-md-2  col-xs-2" style="border: 0px;padding: 0px;">
                    <div id = "C61" class="square1"></div>
                </div>
                <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                    <div id = "C62" class="square1"></div>
                </div>
                <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                    <div id = "C63" class="square1"></div>
                </div>
                <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                    <div id = "C64" class="square1"></div>
                </div>
                <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                    <div id = "C65" class="square1"></div>
                </div>
                <div class="col-md-2  col-xs-2"style="border: 0px;padding: 0px;">
                    <div id = "C66" class="square1"></div>
                </div>
        </div>
        <div class="col-md-3 col-xs-4" class="txt" style="margin:0px;padding:0px;">
                <label class="textalign1"for="exampleInputEmail1">
                    SAMLPLE6
                </label>
        </div>
    </div>
</div>
<div id="textOpt" style="margin-bottom:30px; margin-top:25px;">
    <div style="font-size: 16px;margin: 0px;padding: 0px;font-weight: bold;margin-top: 10px;margin-left: -16px;">
    TEXT:
    </div>
    <hr style="width: 100%;margin: 0px;padding: 0px;">
    <div class="input-group "style="width: 100%; margin-top:5%;">
        <textarea id="addText" type="textbox" placeholder="" class="form-control"style="height: 200px; margin-top: 10px;border-radius: 5px;"></textarea>
    </div>
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-6" style="margin: 0px;padding: 0px;">
            <div class="col-md-12 col-xs-12">
                <div class="textalign" style="font-weight: bold;">
                    SIZE:
                </div>
            </div>
            <div class="col-md-12 col-xs-12">
                <select class="form-control"  id="fontSize" class="form-control" type="number">
				<option value="8">8</option>
				<option value="9">9</option>
				<option value="10">10</option>
				<option value="12">12</option>
				<option value="14">14</option>
				<option value="16">16</option>
				<option value="18">18</option>
				<option value="20">20</option>
				<option value="22">22</option>
				<option value="24">24</option>
				<option value="26">26</option>
				<option value="28">28</option>
				<option value="36">36</option>
				<option value="48">48</option>
				<option value="72">72</option>
				</select>
            </div>
        </div>
        <div class="col-md-6"  style="margin: 0px;padding: 0px;">
            <div class="col-md-12 col-xs-12">
                <div class="textalign" style="font-weight: bold;">
                    FONT:
                </div>
            </div>
            <div class="col-md-12">
                <select class="form-control" id="textfont" style="width: 100%;">
                </select>
            </div>
        </div>
    </div>
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-2 col-xs-12">
            <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
                <div class="textalign" style="font-weight: bold;">
                    STYLE:
                </div>
            </div>
        </div>
        <div class="col-md-10 col-xs-12">
            <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
                <div class="btn-group btn-sm" role="group" aria-label="..." style="width : 100%;">
                    <button type="button" id="bold" class="btn btn-default btn-sm" style="width: 25%;" ><span class="glyphicon glyphicon-bold" aria-hidden="true"></button>
                    <button type="button" id="italic" class="btn btn-default btn-sm" style="width: 25%;"><span class="glyphicon glyphicon-italic" aria-hidden="true"></button>
                    <button type="button" id="underline" class="btn btn-default btn-sm" style="width: 25%;"><span style="font-size:14px;" class="fa fa-underline" aria-hidden="true"></button>
                </div>
            </div>
        </div>
    </div>
    <div class="row" style="margin-top: 5px;">
        <div class="col-md-2 col-xs-12">
            <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
                <div class="textalign" style="font-weight: bold;">
                    ALIGN:
                </div>
            </div>
        </div>
        <div class="col-md-10 col-xs-12">
            <div class=" col-md-12 col-xs-12" style="padding: 0px;margin: 0px;">
                <div class="btn-group btn-sm" role="group" aria-label="..." style="width : 100%;">
                    <button type="button" id="left" class="btn btn-default btn-sm" style="width: 25%;" ><span class="glyphicon glyphicon-align-left" aria-hidden="true"></button>
                    <button type="button" id="right" class="btn btn-default btn-sm" style="width: 25%;"><span class="glyphicon glyphicon-align-right" aria-hidden="true"></button>
                    <button type="button" id="center" class="btn btn-default btn-sm" style="width: 25%;"><span class="glyphicon glyphicon-align-center" aria-hidden="true"></button>
                    <button type="button" id="justify" class="btn btn-default btn-sm" style="width: 25%;"><span class="glyphicon glyphicon-align-justify" aria-hidden="true"></button>
                </div>
            </div>
        </div>
    </div>
    <div class="row" style="margin-top: 6px;margin-bottom: 5px;">
        <div class="col-md-2 col-xs-2 " style="font-weight: bold;padding-top: 3px;margin-right: 15px;">
                COLOR:
        </div>
        <div class="col-md-9 col-xs-9" style="padding: 0px;margin: 0px;font-weight: bold; margin-left: -5px;">
            <div class=" col-md-12 col-xs-12">
                <div id="picker"></div>
            </div>
        </div>
    </div>
</div>
<div id="imageOpt" style="margin-bottom:5px;">
<div class="row" >
    <div class=" col-md-12 col-xs-12" style="margin: 0px;padding: 0px;">
        <div style="font-size: 16px;margin: 0px;padding: 0px;font-weight: bold;">
            IMAGE:
        </div>
        <hr style="width: 100%;margin: 0px;padding: 0px;">
    </div>
    <div class="col-md-12 col-xs-12">
        <div class="rect1" style="width: 100%;margin-top: 10px;">
            <div class="col-md-4 col-xs-4" style="padding: 0px;margin: 0px;">
                <button type="button" style="width:105px;"id="Up-imageUpload" class="btn btn-primary btn-sm" style="font-size: 12px;">Choose File</button>
            </div>
            <div class="col-md-8 col-xs-8">
                <div class="textalign" style="font-size: 14px;margin-left: 20%;">
                    No file choosen
                </div>
            </div>
        </div>
    </div>

    <div  class="col-md-12 col-xs-12" align="center" style="margin-top: 10px; margin-bottom: 10px;">
        <button type="button" id="modal-click" class="btn btn-info btn-sm">Edit Image</button>
    </div>

</div>
</div>
</div>

<div class="row">
    <div class="col-md-6 col-xs-5"  style="margin:0px;padding:0px; padding-left:20px;" align="left">
        <button type="button"  class="btn btn-primary btn-sm">GO BACK</button>
    </div>
    <div class="col-md-6 col-xs-6"  style="margin:0px;padding:0px;padding-right:20px;" align="right" >
        <button type="button"  class="btn btn-primary btn-sm">SAVE&CONTINUE</button>
    </div>
</div>
<input type="hidden" id="base_url" value ="<?php echo base_url() ?>">
<div style="display: none;">
<input type = "file" style="display:none;" id="imageUpload">
</div>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit Picture</h4>
            </div>
            <div class="modal-body" style="min-height: 400px;"><!--Entered Here-->
                <div id="img-Edit">
                    <img src="" width="100%" height="400px">
                </div>
            </div>
            <div class="modal-footer">
                <div class="col-md-12 col-xs-12">
                <div class="col-md-6 col-xs-6" align="left"><button type="button" id="crop-Done-btn" class="btn btn-primary btn-sm">Done</button></div>
                <div class="col-md-6 col-xs-6" align="right"><button type="button" id="crop-End-btn" class="btn btn-default btn-sm" data-dismiss="modal">Close</button></div>
                </div>
            </div>
        </div>

    </div>
</div>
</div>
                        
                     </div>
                     </div>
                     </div>
                  </div>
                     <!-- end: flyer toggle content -->
                  </div>
                  <div class="fusion-panel panel-default">
                     <!-- flyer toggle heading -->
                     <div class="panel-heading">
                        <h4 class="panel-title toggle" data-fontsize="18" data-lineheight="22">
                           <a class="collapsed" data-toggle="collapse" data-parent="#accordion-4104-3" data-target="#toggle-id-4" href="#toggle-id-4">
                              <div class="flyer-heading"><span>Step 4 : </span>Proof.</div>
                           </a>
                        </h4>
                     </div>
                     <!-- end: flyer toggle heading -->
                     <!-- flyer toggle content -->
                     <div id="toggle-id-4" class="panel-collapse collapse">
                        <div class="panel-body toggle-content">
                           <div class="proof-flyer-wrap container-fluid">
                              <div class="row">
                                 <div class="edit-flyer-section col-md-6">
                                    <div class="full-flyer-design">
                                       <img src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg">
                                    </div>
                                 </div>
                                 <div class="edit-flyer-menu col-md-6">
                                    <div class="module">
                                       <div class="input-wrap">
                                          <label class="label-wrap" for="subject">Subject Line <br>
                                          <input type="text" name="subject" placeholder="Subject line">
                                          </label>
                                       </div>
                                       <div class="input-wrap">
                                          <label class="label-wrap" for="email">Email from Line <br>
                                          <input type="text" name="email" placeholder="Email from line">
                                          </label>
                                       </div>
                                       <div class="input-wrap">
                                          <label class="label-wrap" for="email-address">Email Address Line <br>
                                          <input type="text" name="email-address" placeholder="Client Email Address">
                                          </label>
                                       </div>
                                       <div class="input-wrap">
                                          <p class="form-decription">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit officiis velit eum quae numquam illo obcaecati ipsum sunt deleniti assumenda rerum dolorum, fugiat maiores repellendus, hic at culpa neque expedita.</p>
                                       </div>
                                    </div>
                                    <div class="row">
                                       <div class="col-md-3">
                                          <label>Flyer</label>
                                          <img class="img-responsive" src="./Propert Blast - Create New Flyer_files/placeholder-image.jpg">
                                       </div>
                                       <div class="col-md-9">
                                          <p class="input-wrap">
                                             <label for="mls-num">MLS No.</label>
                                             <input type="text" name="mls-num" placeholder="MLS No. : 1234567">								
                                          </p>
                                          <p class="input-wrap">
                                             <label for="listing-price">Listing Price</label>
                                             <input type="text" name="listing-price" placeholder="Listing Price : $567,890">								
                                          </p>
                                          <p class="input-wrap">
                                             <label for="prop-address">Property Address</label>
                                             <input type="text" name="prop-address" placeholder="123 Easy Street, Anytown, USA 87654321">								
                                          </p>
                                          <p class="input-wrap">
                                             <label for="main-header">Main Header</label>
                                             <input type="text" name="main-header" placeholder="This is the best house in the World.">								
                                          </p>
                                          <p class="input-wrap">
                                             <label for="body">Body</label>
                                             <textarea name="body"></textarea>							
                                          </p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <!-- proof-flyer-wrap -->
                           <!-- flyer navigation -->
                           <div class="flyer-navigation clearfix">
                              <a class="fusion-button button-flat button-round button-large button-default" href="http://45.33.34.56/propblast/create-new-flyer/#">
                              <span class="fusion-button-text">Go Back</span>
                              </a>
                              <a class="right fusion-button button-flat button-round button-large button-default" href="http://45.33.34.56/propblast/create-new-flyer/#">
                              <span class="fusion-button-text">Save &amp; Continue</span>
                              </a>
                           </div>
                           <!-- end: flyer navigation -->
                        </div>
                     </div>
                     <!-- end: flyer toggle content -->
                  </div>
                  <div class="fusion-panel panel-default">
                     <!-- flyer toggle heading -->
                     <div class="panel-heading">
                        <h4 class="panel-title toggle" data-fontsize="18" data-lineheight="22">
                           <a class="collapsed" data-toggle="collapse" data-parent="#accordion-4104-3" data-target="-5" href="#toggle-id-5">
                              <div class="flyer-heading"><span>Step 5 : </span>Delivery Area.</div>
                           </a>
                        </h4>
                     </div>
                     <!-- end: flyer toggle heading -->
                     <!-- flyer toggle content -->
                     <div id="toggle-id-5" class="panel-collapse collapse">
                        <div class="panel-body toggle-content">
                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores voluptatibus architecto ullam quos facere ipsum velit sit quidem commodi quaerat libero culpa assumenda numquam tenetur nostrum similique, aliquid dignissimos esse.</p>
                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat dolorem eligendi expedita deleniti labore perferendis iure omnis, explicabo rerum porro, ex nam ea ut inventore illum harum sint minus impedit!</p>
                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat dolorem eligendi expedita deleniti labore perferendis iure omnis, explicabo rerum porro, ex nam ea ut inventore illum harum sint minus impedit!</p>
                           <!-- flyer navigation -->
                           <div class="flyer-navigation clearfix">
                              <a class="fusion-button button-flat button-round button-large button-default" href="http://45.33.34.56/propblast/create-new-flyer/#">
                              <span class="fusion-button-text">Go Back</span>
                              </a>
                              <a class="right fusion-button button-flat button-round button-large button-default" href="http://45.33.34.56/propblast/create-new-flyer/#">
                              <span class="fusion-button-text">Save &amp; Continue</span>
                              </a>
                           </div>
                           <!-- end: flyer navigation -->
                        </div>
                     </div>
                     <!-- end: flyer toggle content -->
                  </div>
                  <div class="fusion-panel panel-default">
                     <!-- flyer toggle heading -->
                     <div class="panel-heading">
                        <h4 class="panel-title toggle" data-fontsize="18" data-lineheight="22">
                           <a class="collapsed" data-toggle="collapse" data-parent="#accordion-4104-3" data-target="#toggle-id-7" href="#toggle-id-7">
                              <div class="flyer-heading"><span>Step 6 : </span>Payment Information.</div>
                           </a>
                        </h4>
                     </div>
                     <!-- end: flyer toggle heading -->
                     <!-- flyer toggle content -->
                     <div id="toggle-id-7" class="panel-collapse collapse">
                        <div class="panel-body toggle-content">
                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum velit veritatis ex quis earum facere voluptatum! Eligendi repellendus, quas vero excepturi maxime ullam fuga quae animi, ratione totam, voluptatibus voluptas.</p>
                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum velit veritatis ex quis earum facere voluptatum! Eligendi repellendus, quas vero excepturi maxime ullam fuga quae animi, ratione totam, voluptatibus voluptas.</p>
                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum velit veritatis ex quis earum facere voluptatum! Eligendi repellendus, quas vero excepturi maxime ullam fuga quae animi, ratione totam, voluptatibus voluptas.</p>
                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolorum velit veritatis ex quis earum facere voluptatum! Eligendi repellendus, quas vero excepturi maxime ullam fuga quae animi, ratione totam, voluptatibus voluptas.</p>
                           <!-- flyer navigation -->
                           <div class="flyer-navigation clearfix">
                              <a class="fusion-button button-flat button-round button-large button-default" href="http://45.33.34.56/propblast/create-new-flyer/#">
                              <span class="fusion-button-text">Go Back</span>
                              </a>
                              <a class="right fusion-button button-flat button-round button-large button-default" href="http://45.33.34.56/propblast/create-new-flyer/#">
                              <span class="fusion-button-text">Save &amp; Continue</span>
                              </a>
                           </div>
                           <!-- end: flyer navigation -->
                        </div>
                     </div>
                     <!-- end: flyer toggle content -->
                  </div>
                  <div class="fusion-panel panel-default">
                     <!-- flyer toggle heading -->
                     <div class="panel-heading">
                        <h4 class="panel-title toggle" data-fontsize="18" data-lineheight="22">
                           <a class="collapsed" data-toggle="collapse" data-parent="#accordion-4104-3" data-target="#toggle-id-8" href="#toggle-id-8">
                              <div class="flyer-heading"><span>Step 8 : </span>Send!.</div>
                           </a>
                        </h4>
                     </div>
                     <!-- end: flyer toggle heading -->
                     <!-- flyer toggle content -->
                     <div id="toggle-id-8" class="panel-collapse collapse">
                        <div class="panel-body toggle-content">
                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis culpa minus ea nisi, odio reiciendis repellendus porro, mollitia iusto voluptatum ducimus saepe rerum similique molestias. Atque, nulla ducimus amet magni.</p>
                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis culpa minus ea nisi, odio reiciendis repellendus porro, mollitia iusto voluptatum ducimus saepe rerum similique molestias. Atque, nulla ducimus amet magni.</p>
                           <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis culpa minus ea nisi, odio reiciendis repellendus porro, mollitia iusto voluptatum ducimus saepe rerum similique molestias. Atque, nulla ducimus amet magni.</p>
                           <!-- flyer navigation -->
                           <div class="flyer-navigation clearfix">
                              <a class="fusion-button button-flat button-round button-large button-default" href="http://45.33.34.56/propblast/create-new-flyer/#">
                              <span class="fusion-button-text">Go Back</span>
                              </a>
                              <a class="right fusion-button button-flat button-round button-large button-default" href="http://45.33.34.56/propblast/create-new-flyer/#">
                              <span class="fusion-button-text">Save &amp; Continue</span>
                              </a>
                           </div>
                           <!-- end: flyer navigation -->
                        </div>
                     </div>
                     <!-- end: flyer toggle content -->
                  </div>
               </div>
            </div>
         </div>
         <!-- fusion-row -->
      </div>
      <!-- #main -->
      <div class="fusion-footer">
         <footer class="fusion-footer-widget-area">
            <div class="fusion-row">
               <div class="col-md-12">
                  <div id="primary-sidebar" class="primary-sidebar widget-area" role="complementary">
                     <div class="custom_widget_class">
                        <div class="menu-footer-menu-1-container">
                           <ul id="menu-footer-menu-1" class="menu">
                              <li id="menu-item-13374" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13374"><a href="http://45.33.34.56/propblast/">Home</a></li>
                              <li id="menu-item-13415" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13415"><a href="http://45.33.34.56/propblast/custom-flyer-design/">Products</a></li>
                              <li id="menu-item-13421" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13421"><a href="http://45.33.34.56/propblast/custom-pricing-page/">Pricing</a></li>
                              <li id="menu-item-13375" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-13375"><a href="http://45.33.34.56/propblast/create-new-flyer/#">Specials</a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="custom_widget_class">
                        <div class="menu-footer-menu-2-container">
                           <ul id="menu-footer-menu-2" class="menu">
                              <li id="menu-item-13376" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13376"><a href="http://45.33.34.56/propblast/">Home</a></li>
                              <li id="menu-item-13417" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13417"><a href="http://45.33.34.56/propblast/privacy-policy/">Privacy Policy</a></li>
                              <li id="menu-item-13416" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13416"><a href="http://45.33.34.56/propblast/terms-conditions/">Terms &amp; Conditions</a></li>
                              <li id="menu-item-13418" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13418"><a href="http://45.33.34.56/propblast/faq/">FAQ</a></li>
                              <li id="menu-item-13419" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-13419"><a href="http://45.33.34.56/propblast/contact/">Contact</a></li>
                           </ul>
                        </div>
                     </div>
                     <div class="custom_widget_class">
                        <div class="textwidget">
                           <ul class="list-inline custom-footer-social-icons">
                              <li><a href="http://45.33.34.56/propblast/create-new-flyer/#"><i class="fa fa-facebook"></i></a></li>
                              <li><a href="http://45.33.34.56/propblast/create-new-flyer/#"><i class="fa fa-twitter"></i></a></li>
                              <li><a href="http://45.33.34.56/propblast/create-new-flyer/#"><i class="fa fa-linkedin"></i></a></li>
                              <li><a href="http://45.33.34.56/propblast/create-new-flyer/#"><i class="fa fa-pinterest"></i></a></li>
                           </ul>
                        </div>
                     </div>
                  </div>
                  <!-- #primary-sidebar -->
               </div>
               <div class="fusion-columns fusion-columns-1 fusion-widget-area">
                  <div class="fusion-column col-lg-12 col-md-12 col-sm-12"></div>
                  <div class="fusion-clearfix"></div>
               </div>
               <!-- fusion-columns -->
            </div>
            <!-- fusion-row -->
         </footer>
         <!-- fusion-footer-area -->
         <footer id="footer" class="fusion-footer-copyright-area">
            <div class="fusion-row">
               <div class="fusion-copyright-content">
                  <div class="new-footer-info">
                     <div class="col-md-6">
                        <strong>Flyers-R-Us</strong> <i class="fa fa-phone-square"></i> 408-555-1212
                     </div>
                     <div class="col-md-6" style="text-align: right;">
                        Copyright <i class="fa fa-copyright"></i> 2015
                     </div>
                  </div>
               </div>
               <!-- fusion-fusion-copyright-area-content -->
            </div>
            <!-- fusion-row -->
         </footer>
         <!-- #footer -->
      </div>
      <!-- fusion-footer -->
      <!-- wrapper -->
      <!-- W3TC-include-js-head -->
      <!-- BEGIN recaptcha, injected by plugin wp-recaptcha-integration  -->
      <div class="to-top-container"><a href="http://45.33.34.56/propblast/create-new-flyer/#" id="toTop" style="display: inline;"><span id="toTopHover"></span></a></div>
   </body>