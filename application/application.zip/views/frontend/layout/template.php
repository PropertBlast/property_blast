<?php 
echo $header;
echo $content;
echo $footer;
