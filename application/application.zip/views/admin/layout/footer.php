 </div>
     <script src="<?php echo base_url('public/admin/js/bootstrap.min.js') ?>"></script>
    <!-- METISMENU SCRIPTS -->
    <script src="<?php echo base_url('public/admin/js/jquery.metisMenu.js') ?>"></script>
    
    <script src="<?php echo base_url('public/admin/js/jquery-ui.js') ?>"></script>
    <script src="<?php echo base_url('public/admin/js/admin-scripts.js') ?>"></script>
    <script src="<?php echo base_url('public/admin/js/colpick.js') ?>"></script>
    <script src="<?php echo base_url('public/admin/js/wan-spinner.js') ?>"></script> 

    <script src="<?php echo base_url('public/admin/js/fabric.min.js') ?>"></script> 
    <script src="<?php echo base_url('public/admin/js/fabric/fabric_api.js') ?>"></script>
    <script src="<?php echo base_url('public/admin/js/script.js') ?>"></script>
    <script src="<?php echo base_url('public/admin/js/fabric/text.js') ?>"></script>
    <script src="<?php echo base_url('public/admin/js/fabric/image.js') ?>"></script>
    <script src="<?php echo base_url('public/admin/js/fabric/shapes.js') ?>"></script>
    <script src="<?php echo base_url('public/admin/js/fabric/colors.js') ?>"></script>

</body>
</html>